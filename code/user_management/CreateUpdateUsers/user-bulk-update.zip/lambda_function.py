import boto3
import json
import csv
import time
import os
import userbulklayer
import traceback
import collections 

s3 = boto3.client("s3")
connect = boto3.client("connect")
instance_id = os.environ['INSTANCE_ID']
bucket = os.environ['BUCKET_NAME']
num_retries = int(os.environ['NUM_RETRIES'])
region = os.environ['AWS_REGION']


def lambda_handler(event, context):
    file_content = userbulklayer.csv_downloader_with_header(event, context, bucket)
    hierarchy_list = userbulklayer.get_hierarchy_list(instance_id)
    routing_profile_list = userbulklayer.get_routing_profile_list(instance_id)
    security_profile_list = userbulklayer.get_security_profile_list(instance_id)
    connect_user_list = userbulklayer.get_connect_users(file_content,instance_id)
    update_users(file_content,hierarchy_list,routing_profile_list,security_profile_list,connect_user_list)
    userbulklayer.rename_file_to_bak(event,context,bucket)


## NOTE: The following columns are expected in the file:
### first name,last name,email address,password,user login,routing profile name,security_profile_name_1|security_profile_name_2,phone type (soft/desk),
###  phone number,soft phone auto accept (yes/no),ACW timeout (seconds),UserHierarchy (level1/level2/level3, etc)
def update_users(file_content, hierarchy_list, routing_profile_list, security_profile_list, connect_user_list):
    header = file_content.pop(0)
    failed_items = do_file_upload(file_content,hierarchy_list,routing_profile_list,security_profile_list,connect_user_list)
    if (failed_items and len(failed_items) > 0):
        # we have failed items, retry
        for x in range (0,num_retries):
            if (len(failed_items) > 0):
                failed_items = do_file_upload(failed_items,hierarchy_list,routing_profile_list,security_profile_list,connect_user_list)
        if (len(failed_items) > 0):
            # write out any remaining failures to a dead letter file
            userbulklayer.write_csv_file(failed_items,"update",bucket,header)

def do_file_upload(file_content, hierarchy_list, routing_profile_list, security_profile_list, connect_user_list):
    id = False
    failed_items = []
    for row in file_content:
        if (len(row) > 0):
            user = row.split(',')
        
            try: 
                connect_user_base = find_connect_user(connect_user_list,user[4])
                connect_user = userbulklayer.describe_user(connect_user_base['Id'],instance_id)
                
                if (connect_user):
                    update_user_identity_config(user, connect_user)
                    update_phone_config(user, connect_user)
                    
                    hierarchy_id = False
                    if len(user[11]) > 0:
                        hierarchy_id = userbulklayer.find_hierarchy_id_by_full_hierarchy_path(user[11],hierarchy_list,instance_id)

                    # hierarchy can be removed
                    if (hierarchy_id):
                        update_user_hierarchy(hierarchy_id, connect_user)
                    else:
                        update_user_hierarchy(False, connect_user)
                        
                    found_id = userbulklayer.find_item_by_name(routing_profile_list, user[5])
                    if (found_id):
                        update_routing_profile(found_id['Id'], connect_user)
                    
                    profile_id_list = userbulklayer.get_security_profile_id_list(security_profile_list, user[6])
                    if (profile_id_list):
                        update_security_profile(profile_id_list, connect_user)
            except Exception as ex:
                print("Error processing update user file: ",ex)
                traceback.print_exc()
                failed_items.append(','.join(user))            
            
    return failed_items                
                    

def find_connect_user(connect_user_list,name):
    return next((item for item in connect_user_list if item["Username"] == name), False)


def update_phone_config(file_user, connect_user):
    time.sleep(.600) # sleep 600 ms between invocations of API to avoid throttling limits
  
    auto_accept = 'yes' if connect_user['PhoneConfig']['AutoAccept'] == True else 'no'
    
    # only update if there's a change
    if (connect_user['PhoneConfig']['PhoneType'] != file_user[7] or 
        auto_accept != file_user[9].lower() or 
        connect_user['PhoneConfig']['AfterContactWorkTimeLimit'] != int(file_user[10]) or
        connect_user['PhoneConfig']['DeskPhoneNumber'] != file_user[8]): 
        
        connect.update_user_phone_config(
            PhoneConfig={
                'PhoneType': file_user[7],
                'AutoAccept': True if file_user[9].lower() == 'yes' else False,
                'AfterContactWorkTimeLimit': int(file_user[10]),
                'DeskPhoneNumber': file_user[8]
            },
            UserId=connect_user['Id'],
            InstanceId=instance_id
        )
    else:
        print('no update on phone data for user ',connect_user['Username'])
    
def update_user_identity_config(file_user, connect_user):
    time.sleep(.600) # sleep 600 ms between invocations of API to avoid throttling limits
    
    if (connect_user['IdentityInfo']['FirstName'] != file_user[0] or 
        connect_user['IdentityInfo']['LastName'] != file_user[1] or
        ('Email' in connect_user['IdentityInfo'] and connect_user['IdentityInfo']['Email'] != file_user[2])):
            
        request_args = {}
        request_args['UserId'] = connect_user['Id']
        request_args['InstanceId'] = instance_id
        request_args['IdentityInfo'] = {}
        request_args['IdentityInfo']['FirstName'] = file_user[0]
        request_args['IdentityInfo']['LastName'] = file_user[1]
        if file_user[2] != None and len(file_user[2]) > 0:
            request_args['IdentityInfo']['Email'] = file_user[2]
            
        connect.update_user_identity_info(**request_args)
    else:
        print('no update on identity data for user ',connect_user['Username'])
        

def update_user_hierarchy(hierarchy_group_id, connect_user):
    time.sleep(.600) # sleep 600 ms between invocations of API to avoid throttling limits
    
    if (('HierarchyGroupId' not in connect_user and hierarchy_group_id) or 
        (connect_user['HierarchyGroupId'] != hierarchy_group_id)):
        request_args = {}
        
        if hierarchy_group_id:
            request_args['HierarchyGroupId'] = hierarchy_group_id
        ## to remove a hierarchy, don't send one (when the issue with the SDK is resolved)
        
        request_args['UserId'] = connect_user['Id']
        request_args['InstanceId'] = instance_id
    
        connect.update_user_hierarchy(**request_args)
    else:
        print('no update on hierarchy data for user ',connect_user['Username'])

def update_routing_profile(routing_profile_id, connect_user):
    time.sleep(.600) # sleep 600 ms between invocations of API to avoid throttling limits
    
    if (connect_user['RoutingProfileId'] != routing_profile_id):
        connect.update_user_routing_profile(
            RoutingProfileId=routing_profile_id,
            UserId=connect_user['Id'],
            InstanceId=instance_id
        )
    else:
        print('no update on routing profile data for user ',connect_user['Username'])


def update_security_profile(security_profile_ids, connect_user):
    time.sleep(.600) # sleep 600 ms between invocations of API to avoid throttling limits
    
    if collections.Counter(connect_user['SecurityProfileIds']) != collections.Counter(security_profile_ids): 
        connect.update_user_security_profiles(
            SecurityProfileIds=
                security_profile_ids,
            UserId=connect_user['Id'],
            InstanceId=instance_id
        )
    else:
        print('no update on security profile data for user ',connect_user['Username'])
