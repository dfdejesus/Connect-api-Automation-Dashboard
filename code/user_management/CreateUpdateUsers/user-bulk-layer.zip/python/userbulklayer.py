# # Lambda layer to contain shared code
import boto3
import csv
from io import StringIO
from datetime import datetime
import urllib

s3 = boto3.client("s3")
s3_resource = boto3.resource("s3")
connect = boto3.client("connect")


def level(i):
        switcher = {
                1:'LevelOne',
                2:'LevelTwo',
                3:'LevelThree',
                4:'LevelFour',
                5:'LevelFive',
                6:'LevelSix'
             }
        return switcher.get(i, "Invalid level")


def csv_downloader_with_header(event, context, bucket):
    if event:        
        file_obj = event["Records"][0]        
        filename = urllib.parse.unquote_plus(file_obj['s3']['object']['key'])
        file_obj2 = s3.get_object(Bucket=bucket, Key=filename)
        file_content = file_obj2["Body"].read().decode('utf-8').split('\r\n')
        
        return file_content


def rename_file_to_bak(event, context, bucket):
    if event:        
        dt = datetime.now()
        timestamp = dt.strftime("%d-%b-%Y.%H:%M:%S")
        file_obj = event["Records"][0]
        filename = urllib.parse.unquote_plus(file_obj['s3']['object']['key'])
        s3_resource.Object(bucket, filename + '.' + timestamp + '.bak').copy_from(CopySource=bucket + '/' + filename)
        # Delete the former object A
        s3_resource.Object(bucket, filename).delete()


def get_hierarchy_list(instance_id):
    response = connect.list_user_hierarchy_groups(
        InstanceId=instance_id,
        MaxResults=1000
    )  
    response_list = response["UserHierarchyGroupSummaryList"]
    while ('NextToken' in response):
        response = connect.list_user_hierarchy_groups(
                InstanceId=instance_id,
                MaxResults=1000,
                NextToken=response['NextToken']
        )
        response_list.update(response["UserHierarchyGroupSummaryList"])   
    return response_list


def get_routing_profile_list(instance_id):
    response = connect.list_routing_profiles(
        InstanceId=instance_id,
        MaxResults=1000
    )  
    response_list = response["RoutingProfileSummaryList"]
    while ('NextToken' in response):
        response = connect.list_routing_profiles(
                InstanceId=instance_id,
                MaxResults=1000,
                NextToken=response['NextToken']
        )
        response_list.update(response["RoutingProfileSummaryList"])   
    return response_list


def get_security_profile_list(instance_id):
    response = connect.list_security_profiles(
        InstanceId=instance_id,
        MaxResults=1000
    )  
    response_list = response["SecurityProfileSummaryList"]
    while ('NextToken' in response):
        response = connect.list_security_profiles(
                InstanceId=instance_id,
                MaxResults=1000,
                NextToken=response['NextToken']
        )
        response_list = response_list + response["SecurityProfileSummaryList"] 
    return response_list


def get_connect_users(file_content, instance_id):
    response = connect.list_users(
        InstanceId=instance_id,
        MaxResults=1000
    )  
    response_list = response["UserSummaryList"]
    while ('NextToken' in response):
        response = connect.list_users(
                InstanceId=instance_id,
                MaxResults=1000,
                NextToken=response['NextToken']
        )
        response_list.update(response["UserSummaryList"])   
    return response_list


def find_item_by_name(search_list, name):
    return next((item for item in search_list if item["Name"] == name), False)


def get_security_profile_id_list(security_profile_list, profile_names):
    names = profile_names.split('|')
    profile_ids = []
    for name in names:
        profile = next((item for item in security_profile_list if item["Name"] == name), False)
        if (profile):
            profile_ids.append(profile['Id'])
    return profile_ids


def write_csv_file(file_content, operation, bucket, header): 
    dt = datetime.now()
    timestamp = dt.strftime("%d-%b-%Y.%H:%M:%S")
    output = StringIO()
    output.write(header + '\n')
    for row in file_content:
        output.write(row + '\n')

    s3.put_object(Body=output.getvalue(), Bucket=bucket, Key="failed/"+ operation +"-failedActions-" + timestamp + ".csv.bak")
    output.close()


def describe_hierarchy_by_id(hierarchy_id, instance_id):
    response = connect.describe_user_hierarchy_group(
        InstanceId=instance_id,
        HierarchyGroupId=hierarchy_id
    )
    return response["HierarchyGroup"]


def describe_user(user_id, instance_id):
    response = connect.describe_user(
        InstanceId=instance_id,
        UserId=user_id
    )
    return response["User"]


def find_hierarchy_id_by_full_hierarchy_path(hierarchy_name, hierarchy_list, instance_id):
    split_hierarchy = hierarchy_name.split('/')
    if (len(split_hierarchy) == 1):
        # only one level, just match by name
        return find_item_by_name(hierarchy_list, hierarchy_name)['Id']
    else:
        lowest_level = len(split_hierarchy)
        
        name = split_hierarchy[lowest_level - 1]
        
        # find all hierarchies that match the name of the lowest level
        lowest = list(filter(lambda hierarchy: hierarchy['Name'] == name, hierarchy_list))
        
        # call describe hierarchy on each matched ID until one entire hierarchy path matches the list
        for h in lowest:
            match = False
            hierarchy_tree = describe_hierarchy_by_id(h['Id'], instance_id)
            
            # if the level # of this path matches the level # of the lowest level in the described hierarchy, we have a potential match
            if (int(hierarchy_tree['LevelId']) == lowest_level):
                # check the other levels to see if they align
                
                for x in range(0, lowest_level - 1):
                    if (hierarchy_tree['HierarchyPath'][level(x + 1)]['Name'] != split_hierarchy[x]):
                        match = False
                        break  # not a match
                    else:
                        match = True  # if we stay true to the end of the loop we have a match
            if match:
                return h['Id']

