import boto3
import json
import csv
import time
import os
import userbulklayer
import traceback

connect = boto3.client("connect")
instance_id = os.environ['INSTANCE_ID']
bucket = os.environ['BUCKET_NAME']
num_retries = int(os.environ['NUM_RETRIES'])


def lambda_handler(event, context):
    file_content = userbulklayer.csv_downloader_with_header(event,context,bucket)
    hierarchy_list = userbulklayer.get_hierarchy_list(instance_id)
    routing_profile_list = userbulklayer.get_routing_profile_list(instance_id)
    security_profile_list = userbulklayer.get_security_profile_list(instance_id)
    new_users = create_users(file_content, security_profile_list, routing_profile_list, hierarchy_list)
    userbulklayer.rename_file_to_bak(event,context,bucket)


## NOTE: The following columns are expected in the file:
### first name,last name,email address,password,user login,routing profile name,security_profile_name_1|security_profile_name_2,phone type (soft/desk),
###  phone number,soft phone auto accept (yes/no),ACW timeout (seconds),UserHierarchy (level1/level2/level3, etc)
def create_users(file_content, security_profile_list, routing_profile_list, hierarchy_list):
    header = file_content.pop(0)
    failed_items = do_file_upload(file_content,security_profile_list,routing_profile_list, hierarchy_list)
    if (len(failed_items) > 0):
        # we have failed items, retry
        for x in range (0,num_retries):
            if (len(failed_items) > 0):
                failed_items = do_file_upload(failed_items,security_profile_list,routing_profile_list, hierarchy_list)
        if (len(failed_items) > 0):
            # write out any remaining failures to a dead letter file
            userbulklayer.write_csv_file(failed_items,"create",bucket,header)
        
def do_file_upload(file_content, security_profile_list, routing_profile_list, hierarchy_list):
    failed_items = []
    for row in file_content:
        user = row.split(',')
        if (len(row) >0): 
            time.sleep(.600) # sleep 600 ms between invocations of API to avoid throttling limits
            try:
                request_args = {}
                request_args['InstanceId'] = instance_id
                request_args['Username'] = user[4]
                
                if user[3] != None and len(user[3]) > 0:
                    request_args['Password'] = user[3] # only send if we have one, no password required if using SSO
                
                if user[2] != None and len(user[2]) > 0:
                    request_args['IdentityInfo'] = {
                            'FirstName': user[0],
                            'LastName': user[1],
                            'Email': user[2]
                        }
                else:
                    request_args['IdentityInfo'] = {
                            'FirstName': user[0],
                            'LastName': user[1]
                        }
                        
                request_args['PhoneConfig'] = {
                        'PhoneType': user[7],
                        'AutoAccept': True if user[9].lower() == 'yes' else False,
                        'AfterContactWorkTimeLimit': int(user[10]),
                        'DeskPhoneNumber': user[8]
                    }
                request_args['RoutingProfileId'] = userbulklayer.find_item_by_name(routing_profile_list, user[5]) ['Id']
                
                security_profile_id_list = userbulklayer.get_security_profile_id_list(security_profile_list, user[6])
                if security_profile_id_list and len(security_profile_id_list) > 0:
                    request_args['SecurityProfileIds'] = security_profile_id_list
                
                if user[11] != None and len(user[11]) > 0:
                    hierarchy_id = userbulklayer.find_hierarchy_id_by_full_hierarchy_path(user[11],hierarchy_list,instance_id)
                    if hierarchy_id:
                        request_args['HierarchyGroupId'] = hierarchy_id
                
                connect.create_user(**request_args)
             
            except Exception as ex:
                print("Error uploading user file: ",ex)
                traceback.print_exc()
                failed_items.append(','.join(user))
            
    return failed_items

